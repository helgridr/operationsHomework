//: Playground - noun: a place where people can play

import UIKit
import Darwin
import Foundation

class Array2D<T>{
    private var cols:Int,rows:Int
    var matrix:[T]//stored the matrix as a column vector to ease column manipulation
    init (cols:Int,rows:Int,defaultValue:T){
        self.cols = cols
        self.rows = rows
        self.matrix = Array(repeating:defaultValue, count:cols*rows)
    }
    subscript (row:Int, col:Int) -> T{//indexes go from 0 to size-1, like go intended
        get {
            return matrix[rows*col + row]
        }
        set{
            matrix[rows*col + row]=newValue
        }
    }
    func columnCount()->Int{
        return cols
    }
    func rowCount()->Int{
        return rows
    }
}
extension Array2D where T == Int{
    func fillWithRandom(){
        self.matrix = (0..<(self.cols * self.rows)).map{($0 % self.rows)}
    }
}//0*/
extension Array2D{
    func shuffleByColumn(){
        var result:[T] = []
        (0..<cols).forEach{col in
            (0..<rows).forEach{row in
                let number = Int(arc4random_uniform(UInt32(rows-row)))
                result.append(self.matrix.remove(at: number))
            }
        }
        self.matrix = result
    }
}
extension Array2D:CustomStringConvertible{
    var description:String{
        var output:[String] = []
        (0..<rows).forEach{row in
            var result:[String] = []
            (0..<cols).forEach{col in
                result.append("\(matrix[rows*col + row])")
            }
            output.append("\(result.joined(separator: ", "))\n")
        }
        return output.joined()
    }//0*/
}

let A = Array2D(cols: 10, rows: 10, defaultValue: 1)
A.fillWithRandom()
A.shuffleByColumn()

class MatrixCrawl:Operation{
    private var done = false
    private let matrix: Array2D<Int>
    private let rows:Int
    private let cols:Int
    /*private*/ var path:[(Int,Int)] = []
    /*private*/ var weight: Int = 0
    
    init(withStartingPoint startingLane: Int, onMatrix matrix:Array2D<Int>){
        self.matrix = matrix
        self.rows = matrix.rowCount()
        self.cols = matrix.columnCount()
        path.append((startingLane,0))
        weight += self.matrix[startingLane,0]

        super.init()
    }
    override func main(){
        (0..<cols-1).forEach{ col in
            let possibleNextStep:[Int]
            let rowIndex:[Int]
            let currentRow = path[col].0
            switch currentRow{
            case 0:
                possibleNextStep = Array(matrix.matrix[(rows*(col+1) + 0) ... (rows*(col+1) + 1)])
                rowIndex = Array(0...1)
            case rows-1:
                possibleNextStep = Array(matrix.matrix[(rows*(col+1) + rows - 2) ... (rows*(col+1) + rows - 1)])
                rowIndex = Array((rows - 2)...(rows - 1))

            default:
                possibleNextStep = Array(matrix.matrix[(rows*(col+1) + currentRow - 1) ... (rows*(col+1) + currentRow + 1)])
                rowIndex = Array((currentRow - 1)...(currentRow + 1))

            }
            let zippedStep = zip(possibleNextStep, rowIndex)
            let nextStep = zippedStep.sorted{$0.0 < $1.0}[0]//this is ok because the next step is never ambiguous

            path.append((nextStep.1, col+1))
            weight += nextStep.0
        }
        
        isFinished = true
    }
    
    override var isFinished: Bool{
        get{
            return done
        }
        set{
            self.done = newValue
        }
    }
}

func sortPaths(ofMatrix matrix:Array2D<Int>){
    print(matrix)

    let queue = OperationQueue()
    var operations:[MatrixCrawl] = []
    (0..<matrix.rowCount()).forEach{
        let op = MatrixCrawl(withStartingPoint: $0, onMatrix: A)
        operations.append(op)
    }
    queue.addOperations(operations, waitUntilFinished: true)
    
    let sortedOps = operations.sorted{
        $0.weight < $1.weight
    }
    (0..<matrix.rowCount()).forEach{
        print("Path: \(sortedOps[$0].path). Total weight \(sortedOps[$0].weight)")
    }
    
}//0*/
let start = ProcessInfo.processInfo.systemUptime
sortPaths(ofMatrix: A)
print(ProcessInfo.processInfo.systemUptime - start)
